Android-Wear-Black-Activity-Template
====================================

This is the Black Activity For Android Wear for those who wish to develop Android Wear app using Eclipse 
and running on latest ADT (23.0.2) where there isn't any wizard to create wear activity.
